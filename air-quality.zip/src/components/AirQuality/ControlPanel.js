
import * as React from 'react';
import { PureComponent } from 'react';

export default class ControlPanel extends PureComponent {
  render() {
    return (
      <div className="control-panel">

      </div>
    );
  }
}